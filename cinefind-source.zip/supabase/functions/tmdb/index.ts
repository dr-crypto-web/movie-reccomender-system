import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const TMDB_KEY = Deno.env.get("TMDB_API_KEY");
const TMDB_BASE = "https://api.themoviedb.org/3";

function isV4Token(key: string) {
  // v4 read-access tokens are JWTs (3 dot-separated parts)
  return key.split(".").length === 3;
}

async function tmdb(path: string, params: Record<string, string> = {}) {
  if (!TMDB_KEY) throw new Error("TMDB_API_KEY not configured");
  const url = new URL(TMDB_BASE + path);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));

  const headers: Record<string, string> = { accept: "application/json" };
  if (isV4Token(TMDB_KEY)) {
    headers.Authorization = `Bearer ${TMDB_KEY}`;
  } else {
    url.searchParams.set("api_key", TMDB_KEY);
  }

  const res = await fetch(url.toString(), { headers });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`TMDB ${res.status}: ${body}`);
  }
  return await res.json();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get("action") ?? "trending";

    let data: unknown;
    if (action === "trending") {
      data = await tmdb("/trending/movie/week");
    } else if (action === "search") {
      const query = url.searchParams.get("query") ?? "";
      if (!query.trim()) {
        return new Response(JSON.stringify({ results: [] }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      data = await tmdb("/search/movie", { query, include_adult: "false" });
    } else if (action === "details") {
      const id = url.searchParams.get("id");
      if (!id) throw new Error("id required");
      data = await tmdb(`/movie/${id}`, { append_to_response: "credits" });
    } else if (action === "recommendations") {
      const id = url.searchParams.get("id");
      if (!id) throw new Error("id required");
      const similar = await tmdb(`/movie/${id}/similar`);
      const recs = (similar as { results: unknown[] }).results.slice(0, 5);
      data = { results: recs };
    } else if (action === "discover") {
      const genres = url.searchParams.get("genres") ?? "";
      const params: Record<string, string> = {
        sort_by: "popularity.desc",
        include_adult: "false",
        "vote_count.gte": "100",
      };
      if (genres) params.with_genres = genres;
      data = await tmdb("/discover/movie", params);
    } else if (action === "videos") {
      const id = url.searchParams.get("id");
      if (!id) throw new Error("id required");
      data = await tmdb(`/movie/${id}/videos`);
    } else if (action === "batch") {
      const ids = (url.searchParams.get("ids") ?? "").split(",").filter(Boolean);
      const results = await Promise.all(
        ids.slice(0, 20).map((id) =>
          tmdb(`/movie/${id}`).catch(() => null),
        ),
      );
      data = { results: results.filter(Boolean) };
    } else {
      throw new Error(`Unknown action: ${action}`);
    }

    return new Response(JSON.stringify(data), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    console.error("tmdb function error:", message);
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
