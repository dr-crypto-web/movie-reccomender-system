import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
const TMDB_KEY = Deno.env.get("TMDB_API_KEY");
const TMDB_BASE = "https://api.themoviedb.org/3";

function isV4Token(key: string) {
  return key.split(".").length === 3;
}

async function tmdb(path: string, params: Record<string, string> = {}) {
  if (!TMDB_KEY) throw new Error("TMDB_API_KEY not configured");
  const url = new URL(TMDB_BASE + path);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const headers: Record<string, string> = { accept: "application/json" };
  if (isV4Token(TMDB_KEY)) {
    headers.Authorization = `Bearer ${TMDB_KEY}`;
  } else {
    url.searchParams.set("api_key", TMDB_KEY);
  }
  const res = await fetch(url.toString(), { headers });
  if (!res.ok) throw new Error(`TMDB ${res.status}`);
  return await res.json();
}

const SYSTEM_PROMPT = `You are CineFind's AI movie concierge. The user describes what they feel like watching (genres, mood, tone, length, era, references). 
Use the search_movies tool to find real movies from TMDB. You can call it multiple times with different queries or genre filters. Then reply with a warm, concise recommendation summary (2-4 sentences) that introduces the picks.
Always call the tool at least once. Keep the final message short and friendly — the UI will render the movie cards separately.`;

const TOOLS = [
  {
    type: "function",
    function: {
      name: "search_movies",
      description: "Search TMDB for movies by a free-text query (title, topic, vibe) and optionally filter by genre names.",
      parameters: {
        type: "object",
        properties: {
          query: { type: "string", description: "Free text search, e.g. 'funny buddy comedy', 'space opera', 'Hangover'" },
          genres: {
            type: "array",
            items: {
              type: "string",
              enum: [
                "Action", "Adventure", "Animation", "Comedy", "Crime", "Documentary",
                "Drama", "Family", "Fantasy", "History", "Horror", "Music",
                "Mystery", "Romance", "Science Fiction", "TV Movie", "Thriller", "War", "Western",
              ],
            },
          },
          limit: { type: "number", description: "How many to return (max 8)", default: 5 },
        },
        required: ["query"],
        additionalProperties: false,
      },
    },
  },
];

const GENRE_MAP: Record<string, number> = {
  Action: 28, Adventure: 12, Animation: 16, Comedy: 35, Crime: 80, Documentary: 99,
  Drama: 18, Family: 10751, Fantasy: 14, History: 36, Horror: 27, Music: 10402,
  Mystery: 9648, Romance: 10749, "Science Fiction": 878, "TV Movie": 10770,
  Thriller: 53, War: 10752, Western: 37,
};

async function searchMoviesTool(args: { query: string; genres?: string[]; limit?: number }) {
  const limit = Math.min(args.limit ?? 5, 8);
  let results: any[] = [];
  if (args.query?.trim()) {
    const s = await tmdb("/search/movie", { query: args.query, include_adult: "false" });
    results = s.results ?? [];
  }
  if (args.genres?.length) {
    const ids = args.genres.map((g) => GENRE_MAP[g]).filter(Boolean).join(",");
    if (ids) {
      const d = await tmdb("/discover/movie", {
        with_genres: ids,
        sort_by: "popularity.desc",
        include_adult: "false",
        "vote_count.gte": "100",
      });
      if (results.length === 0) results = d.results ?? [];
      else {
        const genreSet = new Set(args.genres.map((g) => GENRE_MAP[g]));
        results = results.filter((m: any) =>
          m.genre_ids?.some((id: number) => genreSet.has(id)),
        );
      }
    }
  }
  return results.slice(0, limit).map((m: any) => ({
    id: m.id,
    title: m.title,
    overview: m.overview,
    poster_path: m.poster_path,
    backdrop_path: m.backdrop_path,
    vote_average: m.vote_average,
    release_date: m.release_date,
  }));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");
    const { messages } = await req.json();

    const convo: any[] = [
      { role: "system", content: SYSTEM_PROMPT },
      ...messages,
    ];

    let collectedMovies: any[] = [];

    // allow up to 2 tool-call rounds
    for (let i = 0; i < 3; i++) {
      const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: convo,
          tools: TOOLS,
          tool_choice: i === 0 ? "required" : "auto",
        }),
      });

      if (resp.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit reached, please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (resp.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits in Workspace settings." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (!resp.ok) {
        const t = await resp.text();
        throw new Error(`AI gateway ${resp.status}: ${t}`);
      }

      const data = await resp.json();
      const choice = data.choices?.[0];
      const msg = choice?.message;
      if (!msg) throw new Error("No AI response");

      convo.push(msg);

      const toolCalls = msg.tool_calls ?? [];
      if (toolCalls.length === 0) {
        return new Response(
          JSON.stringify({
            reply: msg.content ?? "Here are some picks for you.",
            movies: dedupeMovies(collectedMovies),
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      for (const tc of toolCalls) {
        if (tc.function?.name === "search_movies") {
          let args: any = {};
          try { args = JSON.parse(tc.function.arguments || "{}"); } catch { /* ignore */ }
          const results = await searchMoviesTool(args);
          collectedMovies.push(...results);
          convo.push({
            role: "tool",
            tool_call_id: tc.id,
            content: JSON.stringify({ results }),
          });
        }
      }
    }

    return new Response(
      JSON.stringify({
        reply: "Here are some picks based on what you described.",
        movies: dedupeMovies(collectedMovies),
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    console.error("movie-chat error:", message);
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

function dedupeMovies(movies: any[]) {
  const seen = new Set<number>();
  const out: any[] = [];
  for (const m of movies) {
    if (!m?.id || seen.has(m.id)) continue;
    seen.add(m.id);
    out.push(m);
    if (out.length >= 8) break;
  }
  return out;
}
